# Y’s Guys League Platform v2.1

## Commissioner Mode

This update adds device-based league management:

- Add completed games
- Add player profiles
- Publish awards
- Automatic browser saving with localStorage
- Download a JSON league backup
- Reset locally saved changes

## Run locally

```bash
npm install
npm run dev
```

## Deploy to Vercel

Framework: Vite  
Build command: `npm run build`  
Output directory: `dist`

Important: v2.1 saves commissioner changes only in the browser/device where they were entered. It is not yet a shared cloud database or password-protected admin system.
